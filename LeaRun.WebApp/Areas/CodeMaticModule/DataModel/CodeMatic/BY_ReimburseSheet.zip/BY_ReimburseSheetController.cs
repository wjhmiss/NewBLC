using LeaRun.Business;
using LeaRun.Entity;
using LeaRun.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LeaRun.WebApp.Areas.CheckSheetModule.Controllers
{
    /// <summary>
    /// �������뵥������
    /// </summary>
    public class BY_ReimburseSheetController : PublicController<BY_ReimburseSheet>
    {
    }
}