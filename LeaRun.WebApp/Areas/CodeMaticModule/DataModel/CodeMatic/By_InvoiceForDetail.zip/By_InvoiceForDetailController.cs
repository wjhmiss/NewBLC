using DNS.Business;
using DNS.Entity;
using DNS.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DNS.WebApp.Areas.CheckSheetModule.Controllers
{
    /// <summary>
    /// By_InvoiceForDetail������
    /// </summary>
    public class By_InvoiceForDetailController : PublicController<By_InvoiceForDetail>
    {
    }
}