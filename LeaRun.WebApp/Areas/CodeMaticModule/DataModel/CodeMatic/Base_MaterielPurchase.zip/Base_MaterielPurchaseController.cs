using DNS.Business;
using DNS.Entity;
using DNS.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DNS.WebApp.Areas.PaymentModule.Controllers
{
    /// <summary>
    /// ���Ϲ������������
    /// </summary>
    public class Base_MaterielPurchaseController : PublicController<Base_MaterielPurchase>
    {
    }
}