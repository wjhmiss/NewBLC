//=====================================================================================
// All Rights Reserved , Copyright @ DNS 2016
// Software Developers @ DNS 2016
//=====================================================================================

using DNS.DataAccess.Attributes;
using DNS.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DNS.Entity
{
    /// <summary>
    /// BY_Stove
    /// <author>
    ///		<name>she</name>
    ///		<date>2016.12.24 13:16</date>
    /// </author>
    /// </summary>
    [Description("BY_Stove")]
    [PrimaryKey("StoveId")]
    public class BY_Stove : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// StoveId
        /// </summary>
        /// <returns></returns>
        [DisplayName("StoveId")]
        public string StoveId { get; set; }
        /// <summary>
        /// StoveCode
        /// </summary>
        /// <returns></returns>
        [DisplayName("StoveCode")]
        public string StoveCode { get; set; }
        /// <summary>
        /// StoveNum
        /// </summary>
        /// <returns></returns>
        [DisplayName("StoveNum")]
        public string StoveNum { get; set; }
        /// <summary>
        /// StartDateTime
        /// </summary>
        /// <returns></returns>
        [DisplayName("StartDateTime")]
        public DateTime? StartDateTime { get; set; }
        /// <summary>
        /// MethodBuilder
        /// </summary>
        /// <returns></returns>
        [DisplayName("MethodBuilder")]
        public string MethodBuilder { get; set; }
        /// <summary>
        /// OperatorName
        /// </summary>
        /// <returns></returns>
        [DisplayName("OperatorName")]
        public string OperatorName { get; set; }
        /// <summary>
        /// StoveType
        /// </summary>
        /// <returns></returns>
        [DisplayName("StoveType")]
        public string StoveType { get; set; }
        /// <summary>
        /// BuildMethod
        /// </summary>
        /// <returns></returns>
        [DisplayName("BuildMethod")]
        public string BuildMethod { get; set; }
        /// <summary>
        /// ��ע
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ע")]
        public string Remark { get; set; }
        /// <summary>
        /// ��Ч
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ч")]
        public int? Enabled { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public int? SortCode { get; set; }
        /// <summary>
        /// ɾ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("ɾ�����")]
        public int? DeleteMark { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// �����û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�����")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// �����û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�")]
        public string CreateUserName { get; set; }
        /// <summary>
        /// �޸�ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸�ʱ��")]
        public DateTime? ModifyDate { get; set; }
        /// <summary>
        /// �޸��û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�����")]
        public string ModifyUserId { get; set; }
        /// <summary>
        /// �޸��û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�")]
        public string ModifyUserName { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.StoveId = CommonHelper.GetGuid;
              if (this.CreateDate == null)
            {
                this.CreateDate = DateTime.Now;
            }             this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.StoveId = KeyValue;
            this.ModifyDate = DateTime.Now;
            this.ModifyUserId = ManageProvider.Provider.Current().UserId;
            this.ModifyUserName = ManageProvider.Provider.Current().UserName;
        }
        #endregion
    }
}