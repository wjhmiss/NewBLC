//=====================================================================================
// All Rights Reserved , Copyright @ DNS 2016
// Software Developers @ DNS 2016
//=====================================================================================

using DNS.DataAccess.Attributes;
using DNS.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DNS.Entity
{
    /// <summary>
    /// BY_StoveHeatList
    /// <author>
    ///		<name>she</name>
    ///		<date>2016.12.24 13:17</date>
    /// </author>
    /// </summary>
    [Description("BY_StoveHeatList")]
    [PrimaryKey("QuotationHeatId")]
    public class BY_StoveHeatList : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// ���۵���ϸID
        /// </summary>
        /// <returns></returns>
        [DisplayName("���۵���ϸID")]
        public string QuotationHeatId { get; set; }
        /// <summary>
        /// StoveId
        /// </summary>
        /// <returns></returns>
        [DisplayName("StoveId")]
        public string StoveId { get; set; }
        /// <summary>
        /// �к�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�к�")]
        public int? QuotationHeatCode { get; set; }
        /// <summary>
        /// �������
        /// </summary>
        /// <returns></returns>
        [DisplayName("�������")]
        public string BoardId { get; set; }
        /// <summary>
        /// �������
        /// </summary>
        /// <returns></returns>
        [DisplayName("�������")]
        public string BoardDescription { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public decimal? Qty { get; set; }
        /// <summary>
        /// ��Ŀ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ŀ���")]
        public string ProjectCode { get; set; }
        /// <summary>
        /// ĥ�Ľ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("ĥ�Ľ�")]
        public int? IsGrindAngle { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public int? IsChamfer { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string SteelId { get; set; }
        /// <summary>
        /// ���ֱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("���ֱ��")]
        public string SteelCode { get; set; }
        /// <summary>
        /// ��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������")]
        public string SteelDescription { get; set; }
        /// <summary>
        /// ������������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������������")]
        public string SteelOtherDescription { get; set; }
        /// <summary>
        /// ����״̬
        /// </summary>
        /// <returns></returns>
        [DisplayName("����״̬")]
        public string SteelState { get; set; }
        /// <summary>
        /// ģ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("ģ��")]
        public string DieCode { get; set; }
        /// <summary>
        /// ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("���")]
        public decimal? Thick { get; set; }
        /// <summary>
        /// ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��")]
        public decimal? Weigh { get; set; }
        /// <summary>
        /// ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��")]
        public decimal? Length { get; set; }
        /// <summary>
        /// �Ƽ�����(���)
        /// </summary>
        /// <returns></returns>
        [DisplayName("�Ƽ�����(���)")]
        public decimal? AddThick { get; set; }
        /// <summary>
        /// �Ƽ�����(��)
        /// </summary>
        /// <returns></returns>
        [DisplayName("�Ƽ�����(��)")]
        public decimal? AddWeigh { get; set; }
        /// <summary>
        /// �Ƽ�����(��)
        /// </summary>
        /// <returns></returns>
        [DisplayName("�Ƽ�����(��)")]
        public decimal? AddLength { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string Technology { get; set; }
        /// <summary>
        /// ��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������")]
        public decimal? Weight { get; set; }
        /// <summary>
        /// ���ϵ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("���ϵ���")]
        public decimal? MaterialPrice { get; set; }
        /// <summary>
        /// �����ۿ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����ۿ�")]
        public decimal? MaterialLess { get; set; }
        /// <summary>
        /// �����ϣ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����ϣ�")]
        public decimal? MaterialAmount { get; set; }
        /// <summary>
        /// С������
        /// </summary>
        /// <returns></returns>
        [DisplayName("С������")]
        public decimal? WorkPrice { get; set; }
        /// <summary>
        /// �ӹ����ۿ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ӹ����ۿ�")]
        public decimal? WorkLess { get; set; }
        /// <summary>
        /// С�����ӹ��ѣ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("С�����ӹ��ѣ�")]
        public decimal? WorkAmount { get; set; }
        /// <summary>
        /// �ȴ�������
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ȴ�������")]
        public decimal? HeatPrice { get; set; }
        /// <summary>
        /// �ȴ����ۿ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ȴ����ۿ�")]
        public decimal? HeatLess { get; set; }
        /// <summary>
        /// ���ȴ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("���ȴ�����")]
        public decimal? HeatAmount { get; set; }
        /// <summary>
        /// ���۶�
        /// </summary>
        /// <returns></returns>
        [DisplayName("���۶�")]
        public decimal? SalesAmount { get; set; }
        /// <summary>
        /// �ɱ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ɱ�")]
        public decimal? CostAmount { get; set; }
        /// <summary>
        /// ë����
        /// </summary>
        /// <returns></returns>
        [DisplayName("ë����")]
        public decimal? ProfitAmount { get; set; }
        /// <summary>
        /// ë����
        /// </summary>
        /// <returns></returns>
        [DisplayName("ë����")]
        public decimal? ProfitRate { get; set; }
        /// <summary>
        /// �ͻ�˵��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�˵��")]
        public string ShipDescription { get; set; }
        /// <summary>
        /// ��ע
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ע")]
        public string Remark { get; set; }
        /// <summary>
        /// ��Ч
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ч")]
        public int? Enabled { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public int? SortCode { get; set; }
        /// <summary>
        /// ɾ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("ɾ�����")]
        public int? DeleteMark { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// �����û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�����")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// �����û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�")]
        public string CreateUserName { get; set; }
        /// <summary>
        /// �޸�ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸�ʱ��")]
        public DateTime? ModifyDate { get; set; }
        /// <summary>
        /// �޸��û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�����")]
        public string ModifyUserId { get; set; }
        /// <summary>
        /// �޸��û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�")]
        public string ModifyUserName { get; set; }
        /// <summary>
        /// �䵥״̬
        /// </summary>
        /// <returns></returns>
        [DisplayName("�䵥״̬")]
        public int? PlaceOrderStatus { get; set; }
        /// <summary>
        /// �ӹ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ӹ�����")]
        public string OrderType { get; set; }
        /// <summary>
        /// �ͻ�������
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�������")]
        public string CustomerOrder { get; set; }
        /// <summary>
        /// �ͻ���Ʒ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ���Ʒ��")]
        public string CustomerProduct { get; set; }
        /// <summary>
        /// ���۵���
        /// </summary>
        /// <returns></returns>
        [DisplayName("���۵���")]
        public string QuotationCode { get; set; }
        /// <summary>
        /// �������
        /// </summary>
        /// <returns></returns>
        [DisplayName("�������")]
        public decimal? LimitWeight { get; set; }
        /// <summary>
        /// ��׺��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��׺��")]
        public decimal? LimitThick { get; set; }
        /// <summary>
        /// �Ƽ����ͣ���kg������
        /// </summary>
        /// <returns></returns>
        [DisplayName("�Ƽ����ͣ���kg������")]
        public string JJtype { get; set; }
        /// <summary>
        /// Ʒ����һ��ֲ����Ӽӹ����ͣ����޸�
        /// </summary>
        /// <returns></returns>
        [DisplayName("Ʒ����һ��ֲ����Ӽӹ����ͣ����޸�")]
        public string ProductName { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public int? LiftingHole { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public int? GasCuttingSteel { get; set; }
        /// <summary>
        /// �׾�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�׾�")]
        public decimal? BoreSize { get; set; }
        /// <summary>
        /// �ֲ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֲ�����")]
        public string SteelType { get; set; }
        /// <summary>
        /// Area
        /// </summary>
        /// <returns></returns>
        [DisplayName("Area")]
        public decimal? Area { get; set; }
        /// <summary>
        /// ��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������")]
        public decimal? TheoryWeight { get; set; }
        /// <summary>
        /// �ͻ�PO
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�PO")]
        public string CustomerPO { get; set; }
        /// <summary>
        /// �ͻ�ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�ID")]
        public string CustomerId { get; set; }
        /// <summary>
        /// �ͻ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ����")]
        public string CustomerCode { get; set; }
        /// <summary>
        /// �ͻ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�����")]
        public string CustomerName { get; set; }
        /// <summary>
        /// �ͻ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ����")]
        public string ShortName { get; set; }
        /// <summary>
        /// ��ϵ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ϵ��")]
        public string ContactName { get; set; }
        /// <summary>
        /// ��ϵ�绰
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ϵ�绰")]
        public string ContactTel { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string ContactFax { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string ContactMail { get; set; }
        /// <summary>
        /// �ֻ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֻ�")]
        public string MobileCode { get; set; }
        /// <summary>
        /// �ͻ���ַ
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ���ַ")]
        public string CustomerAddress { get; set; }
        /// <summary>
        /// TechnologQuery
        /// </summary>
        /// <returns></returns>
        [DisplayName("TechnologQuery")]
        public string TechnologQuery { get; set; }
        /// <summary>
        /// TechnologQueryWrite
        /// </summary>
        /// <returns></returns>
        [DisplayName("TechnologQueryWrite")]
        public string TechnologQueryWrite { get; set; }
        /// <summary>
        /// BillStatus
        /// </summary>
        /// <returns></returns>
        [DisplayName("BillStatus")]
        public string BillStatus { get; set; }
        /// <summary>
        /// HeatStatus
        /// </summary>
        /// <returns></returns>
        [DisplayName("HeatStatus")]
        public string HeatStatus { get; set; }
        /// <summary>
        /// ���˵���
        /// </summary>
        /// <returns></returns>
        [DisplayName("���˵���")]
        public string DeliveryCode { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.QuotationHeatId = CommonHelper.GetGuid;
              if (this.CreateDate == null)
            {
                this.CreateDate = DateTime.Now;
            }             this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.QuotationHeatId = KeyValue;
            this.ModifyDate = DateTime.Now;
            this.ModifyUserId = ManageProvider.Provider.Current().UserId;
            this.ModifyUserName = ManageProvider.Provider.Current().UserName;
        }
        #endregion
    }
}