//=====================================================================================
// All Rights Reserved , Copyright @ DNS 2016
// Software Developers @ DNS 2016
//=====================================================================================

using DNS.Entity;
using DNS.Repository;
using DNS.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace DNS.Business
{
    /// <summary>
    /// BY_QuotationHeat
    /// <author>
    ///		<name>she</name>
    ///		<date>2016.12.22 16:02</date>
    /// </author>
    /// </summary>
    public class BY_QuotationHeatBll : RepositoryFactory<BY_QuotationHeat>
    {
    }
}