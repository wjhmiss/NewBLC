//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2015
// Software Developers @ Learun 2015
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// �ͻ��ȴ������ۿ۱�
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.01.15 10:53</date>
    /// </author>
    /// </summary>
    public class Base_CustomerManageBll : RepositoryFactory<Base_CustomerManage>
    {
    }
}