//=====================================================================================
// All Rights Reserved , Copyright @ DNS 2016
// Software Developers @ DNS 2016
//=====================================================================================

using DNS.Entity;
using DNS.Repository;
using DNS.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace DNS.Business
{
    /// <summary>
    /// Base_SteelDDBeoutDetail
    /// <author>
    ///		<name>she</name>
    ///		<date>2016.06.07 21:43</date>
    /// </author>
    /// </summary>
    public class Base_SteelDDBeoutDetailBll : RepositoryFactory<Base_SteelDDBeoutDetail>
    {
    }
}