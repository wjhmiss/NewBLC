//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2015
// Software Developers @ Learun 2015
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// �ֲ���Ϣ��
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.01.13 14:42</date>
    /// </author>
    /// </summary>
    public class Base_SteelBll : RepositoryFactory<Base_Steel>
    {
    }
}