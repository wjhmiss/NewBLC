//=====================================================================================
// All Rights Reserved , Copyright @ DNS 2015
// Software Developers @ DNS 2015
//=====================================================================================

using DNS.DataAccess.Attributes;
using DNS.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DNS.Entity
{
    /// <summary>
    /// BY_OrderDetailBeOut
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.07.03 20:06</date>
    /// </author>
    /// </summary>
    [Description("BY_OrderDetailBeOut")]
    [PrimaryKey("OrderDetailOutId")]
    public class BY_OrderDetailBeOut : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// ������ϸID
        /// </summary>
        /// <returns></returns>
        [DisplayName("������ϸID")]
        public string OrderDetailOutId { get; set; }
        /// <summary>
        /// ������ϸID
        /// </summary>
        /// <returns></returns>
        [DisplayName("������ϸID")]
        public string OrderDetailId { get; set; }
        /// <summary>
        /// ����ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ID")]
        public string OrderId { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public string OrderCode { get; set; }
        /// <summary>
        /// �к�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�к�")]
        public int? LineCode { get; set; }
        /// <summary>
        /// �������
        /// </summary>
        /// <returns></returns>
        [DisplayName("�������")]
        public string BoardId { get; set; }
        /// <summary>
        /// �������
        /// </summary>
        /// <returns></returns>
        [DisplayName("�������")]
        public string BoardDescription { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public decimal? Qty { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string SteelId { get; set; }
        /// <summary>
        /// ���ֱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("���ֱ��")]
        public string SteelCode { get; set; }
        /// <summary>
        /// ��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������")]
        public string SteelDescription { get; set; }
        /// <summary>
        /// ������������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������������")]
        public string SteelOtherDescription { get; set; }
        /// <summary>
        /// ����״̬
        /// </summary>
        /// <returns></returns>
        [DisplayName("����״̬")]
        public string SteelState { get; set; }
        /// <summary>
        /// ģ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("ģ��")]
        public string DieCode { get; set; }
        /// <summary>
        /// ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("���")]
        public decimal? Thick { get; set; }
        /// <summary>
        /// ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��")]
        public decimal? Weigh { get; set; }
        /// <summary>
        /// ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��")]
        public decimal? Length { get; set; }
        /// <summary>
        /// �깤����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�깤����")]
        public decimal? CompleteQty { get; set; }
        /// <summary>
        /// �򵥼���
        /// </summary>
        /// <returns></returns>
        [DisplayName("�򵥼���")]
        public decimal? PrintQty { get; set; }
        /// <summary>
        /// ִ�б�ע��Ϣ
        /// </summary>
        /// <returns></returns>
        [DisplayName("ִ�б�ע��Ϣ")]
        public string ExecRemark { get; set; }
        /// <summary>
        /// ����״̬
        /// </summary>
        /// <returns></returns>
        [DisplayName("����״̬")]
        public string BillStatus { get; set; }
        /// <summary>
        /// ĥ�Ľ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("ĥ�Ľ�")]
        public int? IsGrindAngle { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public int? IsChamfer { get; set; }
        /// <summary>
        /// ��Ч
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ч")]
        public int? Enabled { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public int? SortCode { get; set; }
        /// <summary>
        /// ɾ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("ɾ�����")]
        public int? DeleteMark { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// �����û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�����")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// �����û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�")]
        public string CreateUserName { get; set; }
        /// <summary>
        /// �޸�ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸�ʱ��")]
        public DateTime? ModifyDate { get; set; }
        /// <summary>
        /// �޸��û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�����")]
        public string ModifyUserId { get; set; }
        /// <summary>
        /// �޸��û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�")]
        public string ModifyUserName { get; set; }
        /// <summary>
        /// ��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������")]
        public decimal? Weight { get; set; }
        /// <summary>
        /// ��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������")]
        public decimal? OpenQty { get; set; }
        /// <summary>
        /// QuotationDetailId
        /// </summary>
        /// <returns></returns>
        [DisplayName("QuotationDetailId")]
        public string QuotationDetailId { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public string ScaleUser { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? ScaleDate { get; set; }
        /// <summary>
        /// ��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������")]
        public string ScaleProcess { get; set; }
        /// <summary>
        /// �ӹ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ӹ�����")]
        public string OrderType { get; set; }
        /// <summary>
        /// ģ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("ģ��")]
        public string DiaCode { get; set; }
        /// <summary>
        /// �Ƿ�ί��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�Ƿ�ί��")]
        public int? IsBeOut { get; set; }
        /// <summary>
        /// ί�����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("ί�����ʱ��")]
        public DateTime? BeOutCompleteDate { get; set; }
        /// <summary>
        /// BeOutCompletePerson
        /// </summary>
        /// <returns></returns>
        [DisplayName("BeOutCompletePerson")]
        public string BeOutCompletePerson { get; set; }
        /// <summary>
        /// �ͻ�ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�ID")]
        public string CustomerId { get; set; }
        /// <summary>
        /// �ͻ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ����")]
        public string CustomerCode { get; set; }
        /// <summary>
        /// �ͻ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�����")]
        public string CustomerName { get; set; }
        /// <summary>
        /// �ͻ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ����")]
        public string ShortName { get; set; }
        /// <summary>
        /// ��ϵ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ϵ��")]
        public string ContactName { get; set; }
        /// <summary>
        /// ��ϵ�绰
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ϵ�绰")]
        public string ContactTel { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string ContactFax { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string ContactMail { get; set; }
        /// <summary>
        /// �ֻ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֻ�")]
        public string MobileCode { get; set; }
        /// <summary>
        /// �ͻ���ַ
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ���ַ")]
        public string CustomerAddress { get; set; }
        /// <summary>
        /// ���ϵ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("���ϵ���")]
        public decimal? MaterialPrice { get; set; }
        /// <summary>
        /// �����ϣ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����ϣ�")]
        public decimal? MaterialAmount { get; set; }
        /// <summary>
        /// �ӹ��ѵ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ӹ��ѵ���")]
        public decimal? WorkPrice { get; set; }
        /// <summary>
        /// ���ӹ��ѣ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("���ӹ��ѣ�")]
        public decimal? WorkAmount { get; set; }
        /// <summary>
        /// �ȴ�������
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ȴ�������")]
        public decimal? HeatPrice { get; set; }
        /// <summary>
        /// ���ȴ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("���ȴ�����")]
        public decimal? HeatAmount { get; set; }
        /// <summary>
        /// ���۶�
        /// </summary>
        /// <returns></returns>
        [DisplayName("���۶�")]
        public decimal? SalesAmount { get; set; }
        /// <summary>
        /// ��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������")]
        public decimal? WeightFact { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.OrderDetailOutId = CommonHelper.GetGuid;
            this.CreateDate = DateTime.Now;
            this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.OrderDetailOutId = KeyValue;
            this.ModifyDate = DateTime.Now;
            this.ModifyUserId = ManageProvider.Provider.Current().UserId;
            this.ModifyUserName = ManageProvider.Provider.Current().UserName;
        }
        #endregion
    }
}