//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2015
// Software Developers @ Learun 2015
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// BY_AdjustQuery
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.03.27 18:57</date>
    /// </author>
    /// </summary>
    public class BY_AdjustQueryBll : RepositoryFactory<BY_AdjustQuery>
    {
    }
}