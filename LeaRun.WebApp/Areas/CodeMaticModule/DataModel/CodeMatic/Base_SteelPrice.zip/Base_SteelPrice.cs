//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2015
// Software Developers @ Learun 2015
//=====================================================================================

using LeaRun.DataAccess.Attributes;
using LeaRun.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LeaRun.Entity
{
    /// <summary>
    /// �ֲļ�Ŀ��
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.01.14 10:31</date>
    /// </author>
    /// </summary>
    [Description("�ֲļ�Ŀ��")]
    [PrimaryKey("SteelPriceId")]
    public class Base_SteelPrice : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// �ֲļ�Ŀ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֲļ�Ŀ����")]
        public string SteelPriceId { get; set; }
        /// <summary>
        /// �ӹ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ӹ�����")]
        public string ProcessType { get; set; }
        /// <summary>
        /// �ֲ���Ϣ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֲ���Ϣ����")]
        public string SteelId { get; set; }
        /// <summary>
        /// �ֲı���
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֲı���")]
        public string SteelCode { get; set; }
        /// <summary>
        /// �ֲ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֲ�����")]
        public string SteelName { get; set; }
        /// <summary>
        /// ͨ�ñ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("ͨ�ñ���")]
        public string CommonCode { get; set; }
        /// <summary>
        /// ���/ֱ����ʼ
        /// </summary>
        /// <returns></returns>
        [DisplayName("���/ֱ����ʼ")]
        public decimal? SizeStart { get; set; }
        /// <summary>
        /// ���/ֱ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("���/ֱ������")]
        public decimal? SizeEnd { get; set; }
        /// <summary>
        /// ��λ
        /// </summary>
        /// <returns></returns>
        [DisplayName("��λ")]
        public string Unit { get; set; }
        /// <summary>
        /// Բ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("Բ��")]
        public int? RoundFeed { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public decimal? Price { get; set; }
        /// <summary>
        /// �ۿ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ۿ���")]
        public decimal? DiscountRate { get; set; }
        /// <summary>
        /// �ۿ۵���
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ۿ۵���")]
        public decimal? DiscountPrice { get; set; }
        /// <summary>
        /// ��ע
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ע")]
        public string Remark { get; set; }
        /// <summary>
        /// ��Ч
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ч")]
        public int? Enabled { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public int? SortCode { get; set; }
        /// <summary>
        /// ɾ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("ɾ�����")]
        public int? DeleteMark { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// �����û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�����")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// �����û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�")]
        public string CreateUserName { get; set; }
        /// <summary>
        /// �޸�ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸�ʱ��")]
        public DateTime? ModifyDate { get; set; }
        /// <summary>
        /// �޸��û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�����")]
        public string ModifyUserId { get; set; }
        /// <summary>
        /// �޸��û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�")]
        public string ModifyUserName { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.SteelPriceId = CommonHelper.GetGuid;
            this.CreateDate = DateTime.Now;
            this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.SteelPriceId = KeyValue;
            this.ModifyDate = DateTime.Now;
            this.ModifyUserId = ManageProvider.Provider.Current().UserId;
            this.ModifyUserName = ManageProvider.Provider.Current().UserName;
        }
        #endregion
    }
}