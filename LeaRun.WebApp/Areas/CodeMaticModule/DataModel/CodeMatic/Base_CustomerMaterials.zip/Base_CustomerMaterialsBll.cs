//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2015
// Software Developers @ Learun 2015
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// �ͻ����Ϸ��ۿ۱�
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.01.15 10:54</date>
    /// </author>
    /// </summary>
    public class Base_CustomerMaterialsBll : RepositoryFactory<Base_CustomerMaterials>
    {
    }
}