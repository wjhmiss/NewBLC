//=====================================================================================
// All Rights Reserved , Copyright @ DNS 2017
// Software Developers @ DNS 2017
//=====================================================================================

using DNS.DataAccess.Attributes;
using DNS.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DNS.Entity
{
    /// <summary>
    /// BY_CJReport
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.04.14 14:44</date>
    /// </author>
    /// </summary>
    [Description("BY_CJReport")]
    [PrimaryKey("CJReportId")]
    public class BY_CJReport : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// CJReportId
        /// </summary>
        /// <returns></returns>
        [DisplayName("CJReportId")]
        public string CJReportId { get; set; }
        /// <summary>
        /// CJReportCode
        /// </summary>
        /// <returns></returns>
        [DisplayName("CJReportCode")]
        public string CJReportCode { get; set; }
        /// <summary>
        /// SteelQualityreportCode
        /// </summary>
        /// <returns></returns>
        [DisplayName("SteelQualityreportCode")]
        public string SteelQualityreportCode { get; set; }
        /// <summary>
        /// QuotationHeatCode
        /// </summary>
        /// <returns></returns>
        [DisplayName("QuotationHeatCode")]
        public string QuotationHeatCode { get; set; }
        /// <summary>
        /// ������ϸID
        /// </summary>
        /// <returns></returns>
        [DisplayName("������ϸID")]
        public string OrderDetailId { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public string OrderLineCode { get; set; }
        /// <summary>
        /// �ͻ�ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�ID")]
        public string CustomerId { get; set; }
        /// <summary>
        /// �ͻ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ����")]
        public string CustomerCode { get; set; }
        /// <summary>
        /// �ͻ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�����")]
        public string CustomerName { get; set; }
        /// <summary>
        /// Qty
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qty")]
        public int? Qty { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string SteelId { get; set; }
        /// <summary>
        /// ���ֱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("���ֱ��")]
        public string SteelCode { get; set; }
        /// <summary>
        /// ��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������")]
        public string SteelDescription { get; set; }
        /// <summary>
        /// Size
        /// </summary>
        /// <returns></returns>
        [DisplayName("Size")]
        public string Size { get; set; }
        /// <summary>
        /// CheckMethod
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckMethod")]
        public string CheckMethod { get; set; }
        /// <summary>
        /// CheckA1
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA1")]
        public string CheckA1 { get; set; }
        /// <summary>
        /// CheckA1Condition
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA1Condition")]
        public string CheckA1Condition { get; set; }
        /// <summary>
        /// CheckA1Result
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA1Result")]
        public string CheckA1Result { get; set; }
        /// <summary>
        /// CheckA2
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA2")]
        public string CheckA2 { get; set; }
        /// <summary>
        /// CheckA2Condition
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA2Condition")]
        public string CheckA2Condition { get; set; }
        /// <summary>
        /// CheckA2Result
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA2Result")]
        public string CheckA2Result { get; set; }
        /// <summary>
        /// CheckA3
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA3")]
        public string CheckA3 { get; set; }
        /// <summary>
        /// CheckA3Condition
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA3Condition")]
        public string CheckA3Condition { get; set; }
        /// <summary>
        /// CheckA3Result
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA3Result")]
        public string CheckA3Result { get; set; }
        /// <summary>
        /// CheckA4
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA4")]
        public string CheckA4 { get; set; }
        /// <summary>
        /// CheckA4Condition
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA4Condition")]
        public string CheckA4Condition { get; set; }
        /// <summary>
        /// CheckA4Result
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA4Result")]
        public string CheckA4Result { get; set; }
        /// <summary>
        /// CheckA5
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA5")]
        public string CheckA5 { get; set; }
        /// <summary>
        /// CheckA5Condition
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA5Condition")]
        public string CheckA5Condition { get; set; }
        /// <summary>
        /// CheckA5Result
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA5Result")]
        public string CheckA5Result { get; set; }
        /// <summary>
        /// CheckA6
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA6")]
        public string CheckA6 { get; set; }
        /// <summary>
        /// CheckA6Condition
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA6Condition")]
        public string CheckA6Condition { get; set; }
        /// <summary>
        /// CheckA6Result
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckA6Result")]
        public string CheckA6Result { get; set; }
        /// <summary>
        /// CheckSteelCode
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckSteelCode")]
        public string CheckSteelCode { get; set; }
        /// <summary>
        /// CheckList
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckList")]
        public string CheckList { get; set; }
        /// <summary>
        /// ִ�б�ע��Ϣ
        /// </summary>
        /// <returns></returns>
        [DisplayName("ִ�б�ע��Ϣ")]
        public string Remark { get; set; }
        /// <summary>
        /// ��Ч
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ч")]
        public int? Enabled { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public int? SortCode { get; set; }
        /// <summary>
        /// ɾ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("ɾ�����")]
        public int? DeleteMark { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// �����û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�����")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// �����û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�")]
        public string CreateUserName { get; set; }
        /// <summary>
        /// �޸�ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸�ʱ��")]
        public DateTime? ModifyDate { get; set; }
        /// <summary>
        /// �޸��û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�����")]
        public string ModifyUserId { get; set; }
        /// <summary>
        /// �޸��û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�")]
        public string ModifyUserName { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.CJReportId = CommonHelper.GetGuid;
              if (this.CreateDate == null)
            {
                this.CreateDate = DateTime.Now;
            }             this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.CJReportId = KeyValue;
            this.ModifyDate = DateTime.Now;
            this.ModifyUserId = ManageProvider.Provider.Current().UserId;
            this.ModifyUserName = ManageProvider.Provider.Current().UserName;
        }
        #endregion
    }
}