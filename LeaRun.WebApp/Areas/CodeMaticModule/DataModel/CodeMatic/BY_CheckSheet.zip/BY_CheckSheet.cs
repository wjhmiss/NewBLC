//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2015
// Software Developers @ Learun 2015
//=====================================================================================

using LeaRun.DataAccess.Attributes;
using LeaRun.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LeaRun.Entity
{
    /// <summary>
    /// ���˵�
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.04.24 11:06</date>
    /// </author>
    /// </summary>
    [Description("���˵�")]
    [PrimaryKey("CheckSheetId")]
    public class BY_CheckSheet : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// ���˵�ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("���˵�ID")]
        public string CheckSheetId { get; set; }
        /// <summary>
        /// ���˵�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("���˵�����")]
        public string CheckSheetCode { get; set; }
        /// <summary>
        /// ��ʼʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ʼʱ��")]
        public DateTime? BeginDate { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? EndDate { get; set; }
        /// <summary>
        /// �ͻ�ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�ID")]
        public string CustomerId { get; set; }
        /// <summary>
        /// �ͻ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ����")]
        public string CustomerCode { get; set; }
        /// <summary>
        /// �ͻ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�����")]
        public string CustomerName { get; set; }
        /// <summary>
        /// �ͻ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ����")]
        public string ShortName { get; set; }
        /// <summary>
        /// ��ϵ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ϵ��")]
        public string ContactName { get; set; }
        /// <summary>
        /// ��ϵ�绰
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ϵ�绰")]
        public string ContactTel { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string ContactFax { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string ContactMail { get; set; }
        /// <summary>
        /// �ֻ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֻ�")]
        public string MobileCode { get; set; }
        /// <summary>
        /// �ͻ���ַ
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ���ַ")]
        public string CustomerAddress { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public decimal? Qty { get; set; }
        /// <summary>
        /// �ܽ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ܽ��")]
        public decimal? TotalAmount { get; set; }
        /// <summary>
        /// �ѻ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ѻ���")]
        public decimal? GetedAmount { get; set; }
        /// <summary>
        /// �Ƿ��ѻ��壬1���壬0δ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�Ƿ��ѻ��壬1���壬0δ����")]
        public int? IsOver { get; set; }
        /// <summary>
        /// �ۿ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ۿ�")]
        public decimal? LessRate { get; set; }
        /// <summary>
        /// �ۿۺ��ܶ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ۿۺ��ܶ�")]
        public decimal? LessedAmount { get; set; }
        /// <summary>
        /// ���ʽ
        /// </summary>
        /// <returns></returns>
        [DisplayName("���ʽ")]
        public string PaymentMode { get; set; }
        /// <summary>
        /// �ͻ���ʽ
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ���ʽ")]
        public string ShipMode { get; set; }
        /// <summary>
        /// ������֯
        /// </summary>
        /// <returns></returns>
        [DisplayName("������֯")]
        public string ShipGroup { get; set; }
        /// <summary>
        /// ���۷�ʽ
        /// </summary>
        /// <returns></returns>
        [DisplayName("���۷�ʽ")]
        public string SalesMode { get; set; }
        /// <summary>
        /// ����Ա
        /// </summary>
        /// <returns></returns>
        [DisplayName("����Ա")]
        public string SalesMan { get; set; }
        /// <summary>
        /// ��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������")]
        public string SalesArea { get; set; }
        /// <summary>
        /// ��ע
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ע")]
        public string Remark { get; set; }
        /// <summary>
        /// ��Ч
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ч")]
        public int? Enabled { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public int? SortCode { get; set; }
        /// <summary>
        /// ɾ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("ɾ�����")]
        public int? DeleteMark { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// �����û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�����")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// �����û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�")]
        public string CreateUserName { get; set; }
        /// <summary>
        /// �޸�ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸�ʱ��")]
        public DateTime? ModifyDate { get; set; }
        /// <summary>
        /// �޸��û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�����")]
        public string ModifyUserId { get; set; }
        /// <summary>
        /// �޸��û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�")]
        public string ModifyUserName { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.CheckSheetId = CommonHelper.GetGuid;
            this.CreateDate = DateTime.Now;
            this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.CheckSheetId = KeyValue;
            this.ModifyDate = DateTime.Now;
            this.ModifyUserId = ManageProvider.Provider.Current().UserId;
            this.ModifyUserName = ManageProvider.Provider.Current().UserName;
        }
        #endregion
    }
}