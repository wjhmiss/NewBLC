//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2015
// Software Developers @ Learun 2015
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// ���˵���ϸ
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.01.24 16:30</date>
    /// </author>
    /// </summary>
    public class BY_DeliveryDetailBll : RepositoryFactory<BY_DeliveryDetail>
    {
    }
}