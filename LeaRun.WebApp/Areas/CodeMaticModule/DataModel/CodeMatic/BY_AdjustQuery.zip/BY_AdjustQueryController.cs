using LeaRun.Business;
using LeaRun.Entity;
using LeaRun.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LeaRun.WebApp.Areas.StorageModule.Controllers
{
    /// <summary>
    /// BY_AdjustQuery������
    /// </summary>
    public class BY_AdjustQueryController : PublicController<BY_AdjustQuery>
    {
    }
}