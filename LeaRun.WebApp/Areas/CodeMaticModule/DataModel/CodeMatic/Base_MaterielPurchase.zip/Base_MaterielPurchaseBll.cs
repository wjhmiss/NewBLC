//=====================================================================================
// All Rights Reserved , Copyright @ DNS 2015
// Software Developers @ DNS 2015
//=====================================================================================

using DNS.Entity;
using DNS.Repository;
using DNS.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace DNS.Business
{
    /// <summary>
    /// ���Ϲ�������
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.07.10 11:52</date>
    /// </author>
    /// </summary>
    public class Base_MaterielPurchaseBll : RepositoryFactory<Base_MaterielPurchase>
    {
    }
}