//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2015
// Software Developers @ Learun 2015
//=====================================================================================

using LeaRun.DataAccess.Attributes;
using LeaRun.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LeaRun.Entity
{
    /// <summary>
    /// �ͻ����Ϸ��ۿ۱�
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.01.15 10:54</date>
    /// </author>
    /// </summary>
    [Description("�ͻ����Ϸ��ۿ۱�")]
    [PrimaryKey("CustomerMaterialsId")]
    public class Base_CustomerMaterials : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// ���Ϸ��ۿ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("���Ϸ��ۿ�����")]
        public string CustomerMaterialsId { get; set; }
        /// <summary>
        /// �ͻ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�����")]
        public string CustomerId { get; set; }
        /// <summary>
        /// �ֲļ�Ŀ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֲļ�Ŀ����")]
        public string SteelPriceId { get; set; }
        /// <summary>
        /// �ֲ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֲ�����")]
        public string SteelId { get; set; }
        /// <summary>
        /// �ֲı���
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֲı���")]
        public string SteelCode { get; set; }
        /// <summary>
        /// �ֲ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֲ�����")]
        public string SteelName { get; set; }
        /// <summary>
        /// ͨ�ñ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("ͨ�ñ���")]
        public string CommonCode { get; set; }
        /// <summary>
        /// ��λ
        /// </summary>
        /// <returns></returns>
        [DisplayName("��λ")]
        public string Unit { get; set; }
        /// <summary>
        /// �ۿ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ۿ���")]
        public decimal? DiscountRate { get; set; }
        /// <summary>
        /// ��Чʱ�� ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Чʱ�� ��")]
        public DateTime? EnabledTimeStart { get; set; }
        /// <summary>
        /// ��Чʱ�� ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Чʱ�� ��")]
        public DateTime? EnabledTimeEnd { get; set; }
        /// <summary>
        /// ��ע
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ע")]
        public string Remark { get; set; }
        /// <summary>
        /// ��Ч
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ч")]
        public int? Enabled { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public int? SortCode { get; set; }
        /// <summary>
        /// ɾ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("ɾ�����")]
        public int? DeleteMark { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// �����û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�����")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// �����û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�")]
        public string CreateUserName { get; set; }
        /// <summary>
        /// �޸�ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸�ʱ��")]
        public DateTime? ModifyDate { get; set; }
        /// <summary>
        /// �޸��û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�����")]
        public string ModifyUserId { get; set; }
        /// <summary>
        /// �޸��û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�")]
        public string ModifyUserName { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.CustomerMaterialsId = CommonHelper.GetGuid;
            this.CreateDate = DateTime.Now;
            this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.CustomerMaterialsId = KeyValue;
            this.ModifyDate = DateTime.Now;
            this.ModifyUserId = ManageProvider.Provider.Current().UserId;
            this.ModifyUserName = ManageProvider.Provider.Current().UserName;
        }
        #endregion
    }
}