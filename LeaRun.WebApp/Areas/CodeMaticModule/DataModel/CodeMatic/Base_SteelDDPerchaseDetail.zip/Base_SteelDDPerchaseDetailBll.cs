//=====================================================================================
// All Rights Reserved , Copyright @ DNS 2016
// Software Developers @ DNS 2016
//=====================================================================================

using DNS.Entity;
using DNS.Repository;
using DNS.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace DNS.Business
{
    /// <summary>
    /// Base_SteelDDPerchaseDetail
    /// <author>
    ///		<name>she</name>
    ///		<date>2016.06.07 21:45</date>
    /// </author>
    /// </summary>
    public class Base_SteelDDPerchaseDetailBll : RepositoryFactory<Base_SteelDDPerchaseDetail>
    {
    }
}