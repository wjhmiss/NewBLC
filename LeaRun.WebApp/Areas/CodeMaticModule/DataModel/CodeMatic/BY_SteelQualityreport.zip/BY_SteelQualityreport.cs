//=====================================================================================
// All Rights Reserved , Copyright @ DNS 2016
// Software Developers @ DNS 2016
//=====================================================================================

using DNS.DataAccess.Attributes;
using DNS.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DNS.Entity
{
    /// <summary>
    /// BY_SteelQualityreport
    /// <author>
    ///		<name>she</name>
    ///		<date>2016.12.16 09:37</date>
    /// </author>
    /// </summary>
    [Description("BY_SteelQualityreport")]
    [PrimaryKey("SteelQualityreportId")]
    public class BY_SteelQualityreport : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// SteelQualityreportId
        /// </summary>
        /// <returns></returns>
        [DisplayName("SteelQualityreportId")]
        public string SteelQualityreportId { get; set; }
        /// <summary>
        /// SteelQualityreportCode
        /// </summary>
        /// <returns></returns>
        [DisplayName("SteelQualityreportCode")]
        public string SteelQualityreportCode { get; set; }
        /// <summary>
        /// �ͻ�ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�ID")]
        public string CustomerId { get; set; }
        /// <summary>
        /// �ͻ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ����")]
        public string CustomerCode { get; set; }
        /// <summary>
        /// �ͻ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�����")]
        public string CustomerName { get; set; }
        /// <summary>
        /// �ֲ���Ϣ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֲ���Ϣ����")]
        public string SteelId { get; set; }
        /// <summary>
        /// �ֲı���
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֲı���")]
        public string SteelCode { get; set; }
        /// <summary>
        /// �ֲ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֲ�����")]
        public string SteelName { get; set; }
        /// <summary>
        /// ¯��
        /// </summary>
        /// <returns></returns>
        [DisplayName("¯��")]
        public string StoveCode { get; set; }
        /// <summary>
        /// ¯��
        /// </summary>
        /// <returns></returns>
        [DisplayName("¯��")]
        public string ParentStoveCode { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string PlaceOrigin { get; set; }
        /// <summary>
        /// Standard
        /// </summary>
        /// <returns></returns>
        [DisplayName("Standard")]
        public string Standard { get; set; }
        /// <summary>
        /// ForgingMethod
        /// </summary>
        /// <returns></returns>
        [DisplayName("ForgingMethod")]
        public string ForgingMethod { get; set; }
        /// <summary>
        /// DeliveryStatus
        /// </summary>
        /// <returns></returns>
        [DisplayName("DeliveryStatus")]
        public string DeliveryStatus { get; set; }
        /// <summary>
        /// ProcessingeUse
        /// </summary>
        /// <returns></returns>
        [DisplayName("ProcessingeUse")]
        public string ProcessingeUse { get; set; }
        /// <summary>
        /// Size
        /// </summary>
        /// <returns></returns>
        [DisplayName("Size")]
        public string Size { get; set; }
        /// <summary>
        /// Qty
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qty")]
        public decimal? Qty { get; set; }
        /// <summary>
        /// Weight
        /// </summary>
        /// <returns></returns>
        [DisplayName("Weight")]
        public decimal? Weight { get; set; }
        /// <summary>
        /// �ֲ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֲ�����")]
        public string SteelType { get; set; }
        /// <summary>
        /// �ܶ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ܶ�")]
        public decimal? Density { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public decimal? Price { get; set; }
        /// <summary>
        /// ��ע
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ע")]
        public string Remark { get; set; }
        /// <summary>
        /// ��Ч
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ч")]
        public int? Enabled { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public int? SortCode { get; set; }
        /// <summary>
        /// ɾ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("ɾ�����")]
        public int? DeleteMark { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// �����û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�����")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// �����û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�")]
        public string CreateUserName { get; set; }
        /// <summary>
        /// �޸�ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸�ʱ��")]
        public DateTime? ModifyDate { get; set; }
        /// <summary>
        /// �޸��û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�����")]
        public string ModifyUserId { get; set; }
        /// <summary>
        /// �޸��û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�")]
        public string ModifyUserName { get; set; }
        /// <summary>
        /// C
        /// </summary>
        /// <returns></returns>
        [DisplayName("C")]
        public string C { get; set; }
        /// <summary>
        /// Mn
        /// </summary>
        /// <returns></returns>
        [DisplayName("Mn")]
        public string Mn { get; set; }
        /// <summary>
        /// Si
        /// </summary>
        /// <returns></returns>
        [DisplayName("Si")]
        public string Si { get; set; }
        /// <summary>
        /// S
        /// </summary>
        /// <returns></returns>
        [DisplayName("S")]
        public string S { get; set; }
        /// <summary>
        /// P
        /// </summary>
        /// <returns></returns>
        [DisplayName("P")]
        public string P { get; set; }
        /// <summary>
        /// Ni
        /// </summary>
        /// <returns></returns>
        [DisplayName("Ni")]
        public string Ni { get; set; }
        /// <summary>
        /// Cr
        /// </summary>
        /// <returns></returns>
        [DisplayName("Cr")]
        public string Cr { get; set; }
        /// <summary>
        /// W
        /// </summary>
        /// <returns></returns>
        [DisplayName("W")]
        public string W { get; set; }
        /// <summary>
        /// V
        /// </summary>
        /// <returns></returns>
        [DisplayName("V")]
        public string V { get; set; }
        /// <summary>
        /// Mo
        /// </summary>
        /// <returns></returns>
        [DisplayName("Mo")]
        public string Mo { get; set; }
        /// <summary>
        /// Cu
        /// </summary>
        /// <returns></returns>
        [DisplayName("Cu")]
        public string Cu { get; set; }
        /// <summary>
        /// DZ1
        /// </summary>
        /// <returns></returns>
        [DisplayName("DZ1")]
        public string DZ1 { get; set; }
        /// <summary>
        /// DZ2
        /// </summary>
        /// <returns></returns>
        [DisplayName("DZ2")]
        public string DZ2 { get; set; }
        /// <summary>
        /// QHJ1
        /// </summary>
        /// <returns></returns>
        [DisplayName("QHJ1")]
        public string QHJ1 { get; set; }
        /// <summary>
        /// QHJ2
        /// </summary>
        /// <returns></returns>
        [DisplayName("QHJ2")]
        public string QHJ2 { get; set; }
        /// <summary>
        /// CJG1
        /// </summary>
        /// <returns></returns>
        [DisplayName("CJG1")]
        public string CJG1 { get; set; }
        /// <summary>
        /// CJG2
        /// </summary>
        /// <returns></returns>
        [DisplayName("CJG2")]
        public string CJG2 { get; set; }
        /// <summary>
        /// Hardness1
        /// </summary>
        /// <returns></returns>
        [DisplayName("Hardness1")]
        public string Hardness1 { get; set; }
        /// <summary>
        /// Hardness2
        /// </summary>
        /// <returns></returns>
        [DisplayName("Hardness2")]
        public string Hardness2 { get; set; }
        /// <summary>
        /// CSBruslt
        /// </summary>
        /// <returns></returns>
        [DisplayName("CSBruslt")]
        public string CSBruslt { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.SteelQualityreportId = CommonHelper.GetGuid;
              if (this.CreateDate == null)
            {
                this.CreateDate = DateTime.Now;
            } \r\n            this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.SteelQualityreportId = KeyValue;
            this.ModifyDate = DateTime.Now;
            this.ModifyUserId = ManageProvider.Provider.Current().UserId;
            this.ModifyUserName = ManageProvider.Provider.Current().UserName;
        }
        #endregion
    }
}