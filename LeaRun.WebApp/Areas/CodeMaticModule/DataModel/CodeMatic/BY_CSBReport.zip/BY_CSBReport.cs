//=====================================================================================
// All Rights Reserved , Copyright @ DNS 2016
// Software Developers @ DNS 2016
//=====================================================================================

using DNS.DataAccess.Attributes;
using DNS.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DNS.Entity
{
    /// <summary>
    /// BY_CSBReport
    /// <author>
    ///		<name>she</name>
    ///		<date>2016.12.17 21:44</date>
    /// </author>
    /// </summary>
    [Description("BY_CSBReport")]
    [PrimaryKey("CSBReportId")]
    public class BY_CSBReport : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// CSBReportId
        /// </summary>
        /// <returns></returns>
        [DisplayName("CSBReportId")]
        public string CSBReportId { get; set; }
        /// <summary>
        /// CSBReportCode
        /// </summary>
        /// <returns></returns>
        [DisplayName("CSBReportCode")]
        public string CSBReportCode { get; set; }
        /// <summary>
        /// ������ϸID
        /// </summary>
        /// <returns></returns>
        [DisplayName("������ϸID")]
        public string OrderDetailId { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public string OrderCode { get; set; }
        /// <summary>
        /// �к�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�к�")]
        public int? LineCode { get; set; }
        /// <summary>
        /// �ͻ�ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�ID")]
        public string CustomerId { get; set; }
        /// <summary>
        /// �ͻ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ����")]
        public string CustomerCode { get; set; }
        /// <summary>
        /// �ͻ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�����")]
        public string CustomerName { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string SteelId { get; set; }
        /// <summary>
        /// ���ֱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("���ֱ��")]
        public string SteelCode { get; set; }
        /// <summary>
        /// ��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������")]
        public string SteelDescription { get; set; }
        /// <summary>
        /// Size
        /// </summary>
        /// <returns></returns>
        [DisplayName("Size")]
        public string Size { get; set; }
        /// <summary>
        /// �ӹ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ӹ�����")]
        public string OrderType { get; set; }
        /// <summary>
        /// �ͻ���Ʒ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ���Ʒ��")]
        public string CustomerProduct { get; set; }
        /// <summary>
        /// Machine
        /// </summary>
        /// <returns></returns>
        [DisplayName("Machine")]
        public string Machine { get; set; }
        /// <summary>
        /// Pinlv
        /// </summary>
        /// <returns></returns>
        [DisplayName("Pinlv")]
        public string Pinlv { get; set; }
        /// <summary>
        /// OHJ
        /// </summary>
        /// <returns></returns>
        [DisplayName("OHJ")]
        public string OHJ { get; set; }
        /// <summary>
        /// CCD
        /// </summary>
        /// <returns></returns>
        [DisplayName("CCD")]
        public string CCD { get; set; }
        /// <summary>
        /// BZ
        /// </summary>
        /// <returns></returns>
        [DisplayName("BZ")]
        public string BZ { get; set; }
        /// <summary>
        /// BW
        /// </summary>
        /// <returns></returns>
        [DisplayName("BW")]
        public string BW { get; set; }
        /// <summary>
        /// Resilt
        /// </summary>
        /// <returns></returns>
        [DisplayName("Resilt")]
        public string Resilt { get; set; }
        /// <summary>
        /// ReportName
        /// </summary>
        /// <returns></returns>
        [DisplayName("ReportName")]
        public string ReportName { get; set; }
        /// <summary>
        /// CheckName
        /// </summary>
        /// <returns></returns>
        [DisplayName("CheckName")]
        public string CheckName { get; set; }
        /// <summary>
        /// ִ�б�ע��Ϣ
        /// </summary>
        /// <returns></returns>
        [DisplayName("ִ�б�ע��Ϣ")]
        public string Remark { get; set; }
        /// <summary>
        /// ��Ч
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ч")]
        public int? Enabled { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public int? SortCode { get; set; }
        /// <summary>
        /// ɾ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("ɾ�����")]
        public int? DeleteMark { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// �����û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�����")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// �����û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�")]
        public string CreateUserName { get; set; }
        /// <summary>
        /// �޸�ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸�ʱ��")]
        public DateTime? ModifyDate { get; set; }
        /// <summary>
        /// �޸��û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�����")]
        public string ModifyUserId { get; set; }
        /// <summary>
        /// �޸��û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�")]
        public string ModifyUserName { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.CSBReportId = CommonHelper.GetGuid;
              if (this.CreateDate == null)
            {
                this.CreateDate = DateTime.Now;
            } \r\n            this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.CSBReportId = KeyValue;
            this.ModifyDate = DateTime.Now;
            this.ModifyUserId = ManageProvider.Provider.Current().UserId;
            this.ModifyUserName = ManageProvider.Provider.Current().UserName;
        }
        #endregion
    }
}