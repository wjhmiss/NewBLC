//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2015
// Software Developers @ Learun 2015
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// �������뵥
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.04.24 22:47</date>
    /// </author>
    /// </summary>
    public class BY_ReimburseSheetBll : RepositoryFactory<BY_ReimburseSheet>
    {
    }
}