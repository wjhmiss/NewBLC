using DNS.Business;
using DNS.Entity;
using DNS.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DNS.WebApp.Areas.OrderModule.Controllers
{
    /// <summary>
    /// BY_OrderDetailBeOut������
    /// </summary>
    public class BY_OrderDetailBeOutController : PublicController<BY_OrderDetailBeOut>
    {
    }
}