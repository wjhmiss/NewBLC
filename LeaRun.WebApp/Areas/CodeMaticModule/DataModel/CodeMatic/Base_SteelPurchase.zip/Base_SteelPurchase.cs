//=====================================================================================
// All Rights Reserved , Copyright @ DNS 2015
// Software Developers @ DNS 2015
//=====================================================================================

using DNS.DataAccess.Attributes;
using DNS.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DNS.Entity
{
    /// <summary>
    /// �ֲĹ�������
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.07.10 11:55</date>
    /// </author>
    /// </summary>
    [Description("�ֲĹ�������")]
    [PrimaryKey("SteelPurchaseId")]
    public class Base_SteelPurchase : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// ����id
        /// </summary>
        /// <returns></returns>
        [DisplayName("����id")]
        public string SteelPurchaseId { get; set; }
        /// <summary>
        /// ���Ϻ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("���Ϻ�")]
        public string SteelPurchaseCode { get; set; }
        /// <summary>
        /// �ͻ�ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�ID")]
        public string CustomerId { get; set; }
        /// <summary>
        /// �ͻ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ����")]
        public string CustomerCode { get; set; }
        /// <summary>
        /// �ͻ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�����")]
        public string CustomerName { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public int? Qty { get; set; }
        /// <summary>
        /// �ܽ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ܽ��")]
        public decimal? TotalMoney { get; set; }
        /// <summary>
        /// ״̬0δ��ˣ�1����ˣ�-1�ܾ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("״̬0δ��ˣ�1����ˣ�-1�ܾ�")]
        public int? Status { get; set; }
        /// <summary>
        /// �Ѹ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("�Ѹ���")]
        public int? IsPay { get; set; }
        /// <summary>
        /// �ѿ�Ʊ
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ѿ�Ʊ")]
        public int? IsInvoice { get; set; }
        /// <summary>
        /// ֧����ʽ
        /// </summary>
        /// <returns></returns>
        [DisplayName("֧����ʽ")]
        public string PayType { get; set; }
        /// <summary>
        /// Ա��ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("Ա��ID")]
        public string WorkerId { get; set; }
        /// <summary>
        /// Ա������
        /// </summary>
        /// <returns></returns>
        [DisplayName("Ա������")]
        public string WorkerName { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string WorkerCode { get; set; }
        /// <summary>
        /// ��ע
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ע")]
        public string Remark { get; set; }
        /// <summary>
        /// ��Ч
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ч")]
        public int? Enabled { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public int? SortCode { get; set; }
        /// <summary>
        /// ɾ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("ɾ�����")]
        public int? DeleteMark { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// �����û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�����")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// �����û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�")]
        public string CreateUserName { get; set; }
        /// <summary>
        /// �޸�ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸�ʱ��")]
        public DateTime? ModifyDate { get; set; }
        /// <summary>
        /// �޸��û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�����")]
        public string ModifyUserId { get; set; }
        /// <summary>
        /// �޸��û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�")]
        public string ModifyUserName { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.SteelPurchaseId = CommonHelper.GetGuid;
            this.CreateDate = DateTime.Now;
            this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.SteelPurchaseId = KeyValue;
            this.ModifyDate = DateTime.Now;
            this.ModifyUserId = ManageProvider.Provider.Current().UserId;
            this.ModifyUserName = ManageProvider.Provider.Current().UserName;
        }
        #endregion
    }
}