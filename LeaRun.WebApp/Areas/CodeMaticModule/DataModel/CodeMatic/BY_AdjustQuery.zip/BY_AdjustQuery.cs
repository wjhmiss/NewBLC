//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2015
// Software Developers @ Learun 2015
//=====================================================================================

using LeaRun.DataAccess.Attributes;
using LeaRun.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LeaRun.Entity
{
    /// <summary>
    /// BY_AdjustQuery
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.03.27 18:57</date>
    /// </author>
    /// </summary>
    [Description("BY_AdjustQuery")]
    [PrimaryKey("InventoryId")]
    public class BY_AdjustQuery : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// ���ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("���ID")]
        public string InventoryId { get; set; }
        /// <summary>
        /// ParentInventoryId
        /// </summary>
        /// <returns></returns>
        [DisplayName("ParentInventoryId")]
        public string ParentInventoryId { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string SteelId { get; set; }
        /// <summary>
        /// ���ֱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("���ֱ��")]
        public string SteelCode { get; set; }
        /// <summary>
        /// ��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������")]
        public string SteelDescription { get; set; }
        /// <summary>
        /// ������������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������������")]
        public string SteelOtherDescription { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string PlaceOrigin { get; set; }
        /// <summary>
        /// ���ʣ�0-���ϣ�1-���ϣ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("���ʣ�0-���ϣ�1-���ϣ�")]
        public int? MaterialType { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string SteelType { get; set; }
        /// <summary>
        /// �ְ�״̬
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ְ�״̬")]
        public string SteelStatus { get; set; }
        /// <summary>
        /// ���κ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("���κ�")]
        public string BatchCode { get; set; }
        /// <summary>
        /// �����Σ���*��*����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����Σ���*��*����")]
        public string ChildBatch { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public decimal? Qty { get; set; }
        /// <summary>
        /// ¯��
        /// </summary>
        /// <returns></returns>
        [DisplayName("¯��")]
        public string StoveCode { get; set; }
        /// <summary>
        /// �ֳ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֳ�����")]
        public string FactoryCode { get; set; }
        /// <summary>
        /// ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("���")]
        public decimal? Thick { get; set; }
        /// <summary>
        /// ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��")]
        public decimal? Weigh { get; set; }
        /// <summary>
        /// ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��")]
        public decimal? Length { get; set; }
        /// <summary>
        /// ��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������")]
        public decimal? TheoryWeight { get; set; }
        /// <summary>
        /// ʵ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("ʵ������")]
        public decimal? Weight { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public decimal? Price { get; set; }
        /// <summary>
        /// ��ע
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ע")]
        public string Remark { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? InStockDate { get; set; }
        /// <summary>
        /// ��Ч
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ч")]
        public int? Enabled { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public int? SortCode { get; set; }
        /// <summary>
        /// ɾ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("ɾ�����")]
        public int? DeleteMark { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// �����û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�����")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// �����û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�")]
        public string CreateUserName { get; set; }
        /// <summary>
        /// �޸�ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸�ʱ��")]
        public DateTime? ModifyDate { get; set; }
        /// <summary>
        /// �޸��û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�����")]
        public string ModifyUserId { get; set; }
        /// <summary>
        /// �޸��û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�")]
        public string ModifyUserName { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.InventoryId = CommonHelper.GetGuid;
            this.CreateDate = DateTime.Now;
            this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.InventoryId = KeyValue;
            this.ModifyDate = DateTime.Now;
            this.ModifyUserId = ManageProvider.Provider.Current().UserId;
            this.ModifyUserName = ManageProvider.Provider.Current().UserName;
        }
        #endregion
    }
}