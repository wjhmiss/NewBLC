//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2015
// Software Developers @ Learun 2015
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// ����ת��
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.03.17 11:04</date>
    /// </author>
    /// </summary>
    public class BY_OrderDetailBll : RepositoryFactory<BY_OrderDetail>
    {
    }
}