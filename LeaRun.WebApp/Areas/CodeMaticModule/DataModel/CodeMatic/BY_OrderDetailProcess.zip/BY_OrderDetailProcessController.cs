using LeaRun.Business;
using LeaRun.Entity;
using LeaRun.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LeaRun.WebApp.Areas.OrderDetailProcessModule.Controllers
{
    /// <summary>
    /// ���������������
    /// </summary>
    public class BY_OrderDetailProcessController : PublicController<BY_OrderDetailProcess>
    {
    }
}