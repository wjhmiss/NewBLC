//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2015
// Software Developers @ Learun 2015
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// ExportExcels
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.04.24 20:00</date>
    /// </author>
    /// </summary>
    public class ExportExcelsBll : RepositoryFactory<ExportExcels>
    {
    }
}