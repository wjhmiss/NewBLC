//=====================================================================================
// All Rights Reserved , Copyright @ DNS 2016
// Software Developers @ DNS 2016
//=====================================================================================

using DNS.DataAccess.Attributes;
using DNS.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DNS.Entity
{
    /// <summary>
    /// Base_SetPerformanceForArea
    /// <author>
    ///		<name>she</name>
    ///		<date>2016.04.11 01:51</date>
    /// </author>
    /// </summary>
    [Description("Base_SetPerformanceForArea")]
    [PrimaryKey("SetPerformanceId")]
    public class Base_SetPerformanceForArea : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// id
        /// </summary>
        /// <returns></returns>
        [DisplayName("id")]
        public string SetPerformanceId { get; set; }
        /// <summary>
        /// ����ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ID")]
        public string TechnologyId { get; set; }
        /// <summary>
        /// ��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������")]
        public string TechnologyName { get; set; }
        /// <summary>
        /// �ֲ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֲ�����")]
        public string SteelType { get; set; }
        /// <summary>
        /// �ӹ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ӹ�����")]
        public string OrderType { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public decimal? LimitArea { get; set; }
        /// <summary>
        /// ÿƽ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("ÿƽ������")]
        public decimal? PriceArea { get; set; }
        /// <summary>
        /// ��ע
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ע")]
        public string Remark { get; set; }
        /// <summary>
        /// ��Ч
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ч")]
        public int? Enabled { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public int? SortCode { get; set; }
        /// <summary>
        /// ɾ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("ɾ�����")]
        public int? DeleteMark { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// �����û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�����")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// �����û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�")]
        public string CreateUserName { get; set; }
        /// <summary>
        /// �޸�ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸�ʱ��")]
        public DateTime? ModifyDate { get; set; }
        /// <summary>
        /// �޸��û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�����")]
        public string ModifyUserId { get; set; }
        /// <summary>
        /// �޸��û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�")]
        public string ModifyUserName { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public decimal? PercentWorkAmount { get; set; }
        /// <summary>
        /// �� ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�� ��")]
        public decimal? PachyStart { get; set; }
        /// <summary>
        /// �� ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�� ��")]
        public decimal? PachyEnd { get; set; }
        /// <summary>
        /// �� ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�� ��")]
        public decimal? WidthStart { get; set; }
        /// <summary>
        /// �� ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�� ��")]
        public decimal? WidthEnd { get; set; }
        /// <summary>
        /// �� ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�� ��")]
        public decimal? LengthStart { get; set; }
        /// <summary>
        /// �� ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�� ��")]
        public decimal? LengthEnd { get; set; }
        /// <summary>
        /// ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("���")]
        public int? OrOr { get; set; }
        /// <summary>
        /// �� ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�� ��")]
        public decimal? WeightStart { get; set; }
        /// <summary>
        /// �� ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�� ��")]
        public decimal? WeightEnd { get; set; }
        /// <summary>
        /// ����С�ڣ�Z���۸�С�ڣ�J
        /// </summary>
        /// <returns></returns>
        [DisplayName("����С�ڣ�Z���۸�С�ڣ�J")]
        public string WhereQ { get; set; }
        /// <summary>
        /// ��λ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��λ��")]
        public decimal? WhereQty { get; set; }
        /// <summary>
        /// Unit
        /// </summary>
        /// <returns></returns>
        [DisplayName("Unit")]
        public string Unit { get; set; }
        /// <summary>
        /// Price
        /// </summary>
        /// <returns></returns>
        [DisplayName("Price")]
        public decimal? Price { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.SetPerformanceId = CommonHelper.GetGuid;
            this.CreateDate = DateTime.Now;
            this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.SetPerformanceId = KeyValue;
            this.ModifyDate = DateTime.Now;
            this.ModifyUserId = ManageProvider.Provider.Current().UserId;
            this.ModifyUserName = ManageProvider.Provider.Current().UserName;
        }
        #endregion
    }
}