//=====================================================================================
// All Rights Reserved , Copyright @ DNS 2016
// Software Developers @ DNS 2016
//=====================================================================================

using DNS.DataAccess.Attributes;
using DNS.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DNS.Entity
{
    /// <summary>
    /// Base_Sheet
    /// <author>
    ///		<name>she</name>
    ///		<date>2016.11.02 13:44</date>
    /// </author>
    /// </summary>
    [Description("Base_Sheet")]
    [PrimaryKey("SheetId")]
    public class Base_Sheet : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// ����id
        /// </summary>
        /// <returns></returns>
        [DisplayName("����id")]
        public string SheetId { get; set; }
        /// <summary>
        /// �����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����")]
        public string SheetCode { get; set; }
        /// <summary>
        /// ��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������")]
        public string PayName { get; set; }
        /// <summary>
        /// ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("���")]
        public string Size { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public decimal? PricePer { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public int? Qty { get; set; }
        /// <summary>
        /// �ܽ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ܽ��")]
        public decimal? TotalAmount { get; set; }
        /// <summary>
        /// ״̬0δ��ˣ�1����ˣ�-1�ܾ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("״̬0δ��ˣ�1����ˣ�-1�ܾ�")]
        public int? Status { get; set; }
        /// <summary>
        /// �Ѹ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("�Ѹ���")]
        public int? IsPay { get; set; }
        /// <summary>
        /// �ѿ�Ʊ
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ѿ�Ʊ")]
        public int? IsInvoice { get; set; }
        /// <summary>
        /// ֧����ʽ
        /// </summary>
        /// <returns></returns>
        [DisplayName("֧����ʽ")]
        public string PayType { get; set; }
        /// <summary>
        /// Ա��ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("Ա��ID")]
        public string WorkerId { get; set; }
        /// <summary>
        /// Ա������
        /// </summary>
        /// <returns></returns>
        [DisplayName("Ա������")]
        public string WorkerName { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string WorkerCode { get; set; }
        /// <summary>
        /// ��ע
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ע")]
        public string Remark { get; set; }
        /// <summary>
        /// ��Ч
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ч")]
        public int? Enabled { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public int? SortCode { get; set; }
        /// <summary>
        /// ɾ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("ɾ�����")]
        public int? DeleteMark { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// �����û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�����")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// �����û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�")]
        public string CreateUserName { get; set; }
        /// <summary>
        /// �޸�ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸�ʱ��")]
        public DateTime? ModifyDate { get; set; }
        /// <summary>
        /// �޸��û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�����")]
        public string ModifyUserId { get; set; }
        /// <summary>
        /// �޸��û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�")]
        public string ModifyUserName { get; set; }
        /// <summary>
        /// DepartmentName
        /// </summary>
        /// <returns></returns>
        [DisplayName("DepartmentName")]
        public string DepartmentName { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? UseDate { get; set; }
        /// <summary>
        /// �ѻ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ѻ���")]
        public decimal? GetedAmount { get; set; }
        /// <summary>
        /// PayName1
        /// </summary>
        /// <returns></returns>
        [DisplayName("PayName1")]
        public string PayName1 { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.SheetId = CommonHelper.GetGuid;
              if (this.CreateDate == null)
            {
                this.CreateDate = DateTime.Now;
            } \r\n            this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.SheetId = KeyValue;
            this.ModifyDate = DateTime.Now;
            this.ModifyUserId = ManageProvider.Provider.Current().UserId;
            this.ModifyUserName = ManageProvider.Provider.Current().UserName;
        }
        #endregion
    }
}