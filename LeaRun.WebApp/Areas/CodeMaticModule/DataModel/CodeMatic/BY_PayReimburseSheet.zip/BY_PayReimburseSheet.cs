//=====================================================================================
// All Rights Reserved , Copyright @ DNS 2016
// Software Developers @ DNS 2016
//=====================================================================================

using DNS.DataAccess.Attributes;
using DNS.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DNS.Entity
{
    /// <summary>
    /// �������
    /// <author>
    ///		<name>she</name>
    ///		<date>2016.03.31 11:05</date>
    /// </author>
    /// </summary>
    [Description("�������")]
    [PrimaryKey("PayReimburseSheetID")]
    public class BY_PayReimburseSheet : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// ���뵥ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("���뵥ID")]
        public string PayReimburseSheetID { get; set; }
        /// <summary>
        /// ���뵥��
        /// </summary>
        /// <returns></returns>
        [DisplayName("���뵥��")]
        public string PayReimburseSheetCode { get; set; }
        /// <summary>
        /// Code
        /// </summary>
        /// <returns></returns>
        [DisplayName("Code")]
        public string Code { get; set; }
        /// <summary>
        /// "0"�տ  "1"���˵�  "2"���˵�
        /// </summary>
        /// <returns></returns>
        [DisplayName(""0"�տ  "1"���˵�  "2"���˵�")]
        public string CodeType { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public string RequiredMan { get; set; }
        /// <summary>
        /// ��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������")]
        public DateTime? RequiredDate { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public decimal? RequiredMoney { get; set; }
        /// <summary>
        /// �����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����")]
        public string AuditMan { get; set; }
        /// <summary>
        /// AuditDateTime
        /// </summary>
        /// <returns></returns>
        [DisplayName("AuditDateTime")]
        public DateTime? AuditDateTime { get; set; }
        /// <summary>
        /// AuditRemark
        /// </summary>
        /// <returns></returns>
        [DisplayName("AuditRemark")]
        public string AuditRemark { get; set; }
        /// <summary>
        /// ״̬0δ��ˣ�1����ˣ�-1�ܾ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("״̬0δ��ˣ�1����ˣ�-1�ܾ�")]
        public int? Status { get; set; }
        /// <summary>
        /// ��ע
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ע")]
        public string Remark { get; set; }
        /// <summary>
        /// ��Ч
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ч")]
        public int? Enabled { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public int? SortCode { get; set; }
        /// <summary>
        /// ɾ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("ɾ�����")]
        public int? DeleteMark { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// �����û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�����")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// �����û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����û�")]
        public string CreateUserName { get; set; }
        /// <summary>
        /// �޸�ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸�ʱ��")]
        public DateTime? ModifyDate { get; set; }
        /// <summary>
        /// �޸��û�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�����")]
        public string ModifyUserId { get; set; }
        /// <summary>
        /// �޸��û�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��û�")]
        public string ModifyUserName { get; set; }
        /// <summary>
        /// �ͻ�ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�ID")]
        public string CustomerId { get; set; }
        /// <summary>
        /// �ͻ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ����")]
        public string CustomerCode { get; set; }
        /// <summary>
        /// �ͻ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ͻ�����")]
        public string CustomerName { get; set; }
        /// <summary>
        /// ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("������")]
        public string MnemonicCode { get; set; }
        /// <summary>
        /// ���۵���
        /// </summary>
        /// <returns></returns>
        [DisplayName("���۵���")]
        public string QuotationCode { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public decimal? ZRMoney { get; set; }
        /// <summary>
        /// ʵ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("ʵ��")]
        public decimal? GETMoney { get; set; }
        /// <summary>
        /// ��δ�յ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("��δ�յ�")]
        public decimal? NotGetMoney { get; set; }
        /// <summary>
        /// �ֽ�,֧Ʊ���ж�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֽ�,֧Ʊ���ж�")]
        public string GetType { get; set; }
        /// <summary>
        /// Ԥ�տ�ֽ�Ӧ�տ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("Ԥ�տ�ֽ�Ӧ�տ�")]
        public string Opions { get; set; }
        /// <summary>
        /// ���ý��
        /// </summary>
        /// <returns></returns>
        [DisplayName("���ý��")]
        public decimal? CanUseMoney { get; set; }
        /// <summary>
        /// Ӧ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("Ӧ��")]
        public decimal? TotalMoney { get; set; }
        /// <summary>
        /// InvoiceNum
        /// </summary>
        /// <returns></returns>
        [DisplayName("InvoiceNum")]
        public string InvoiceNum { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.PayReimburseSheetID = CommonHelper.GetGuid;
            this.CreateDate = DateTime.Now;
            this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.PayReimburseSheetID = KeyValue;
            this.ModifyDate = DateTime.Now;
            this.ModifyUserId = ManageProvider.Provider.Current().UserId;
            this.ModifyUserName = ManageProvider.Provider.Current().UserName;
        }
        #endregion
    }
}