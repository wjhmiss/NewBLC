using DNS.Business;
using DNS.Entity;
using DNS.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DNS.WebApp.Areas.QuotationHeatModule.Controllers
{
    /// <summary>
    /// BY_QuotationHeatBeoutDetail������
    /// </summary>
    public class BY_QuotationHeatBeoutDetailController : PublicController<BY_QuotationHeatBeoutDetail>
    {
    }
}